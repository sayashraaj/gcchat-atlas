const path = require('path');
const bodyParser = require('body-parser')
const http = require('http');
const express = require('express');
const socketio = require('socket.io');
const formatMessage = require('./utils/messages');
//
const passport = require('passport');
const cookieSession = require('cookie-session')
require('./passport-setup');
//
const {
  userJoin,
  getCurrentUser,
  userLeave,
  getRoomUsers
} = require('./utils/users');

const app = express();
const server = http.createServer(app);
const io = socketio(server);

// Set static folder
app.use(express.static(path.join(__dirname, 'public')));
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
// parse application/json
app.use(bodyParser.json())
// set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
//
app.use(cookieSession({
    name: 'tuto-session',
    keys: ['key1', 'key2']
  }))

// Auth middleware that checks if the user is logged in
const isLoggedIn = (req, res, next) => {
    if (req.user) {
        // console.log(req.user);
        next();
    } else {
        // res.sendStatus(401);
        res.redirect('/google')
    }
}

// Initializes passport and passport sessions
app.use(passport.initialize());
app.use(passport.session());
// Example protected and unprotected routes
app.get('/', (req, res) => res.render('home'))
app.get('/failed', (req, res) => res.send('You Failed to log in!'))

// In this route you can see that if the user is logged in u can access his info in: req.user
app.get('/good', isLoggedIn, (req, res) => res.redirect('/'))

// Auth Routes
app.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

app.get('/google/callback', passport.authenticate('google', { failureRedirect: '/failed' }),
  function(req, res) {
    if(req.user._json.hd === "smail.iitm.ac.in"){
        // find or create user in database, etc
        res.redirect('/good');
    }else{
        // fail        
        // res.send('Only Smail permitted');
        res.redirect('/logout');
    }
    // Successful authentication, redirect home.
  }
);

app.get('/logout', (req, res) => {
    req.session = null;
    req.logout();
    res.redirect('/');
})
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const botName = 'GcBot';

// Run when client connects
try{
io.on('connection', socket => {
  socket.on('joinRoom', ({ username, room }) => {
    const user = userJoin(socket.id, username, room);

    socket.join(user.room);

    // Welcome current user
    socket.emit('message', formatMessage(botName, 'Welcome to GcChat!'));

    // Broadcast when a user connects
    socket.broadcast
      .to(user.room)
      .emit(
        'message',
        formatMessage(botName, `${user.username} has joined the chat`)
      );

    // Send users and room info
    io.to(user.room).emit('roomUsers', {
      room: user.room,
      users: getRoomUsers(user.room)
    });
  });

  // Listen for chatMessage
  socket.on('chatMessage', msg => {
    const user = getCurrentUser(socket.id);
    if(!user){
    	// return res.send('error')
		socket.emit('redirect', '/logout');
    }
    else io.to(user.room).emit('message', formatMessage(user.username, msg));
  });

  // Runs when client disconnects
  socket.on('disconnect', () => {
    const user = userLeave(socket.id);

    if (user) {
      io.to(user.room).emit(
        'message',
        formatMessage(botName, `${user.username} has left the chat`)
      );

      // Send users and room info
      io.to(user.room).emit('roomUsers', {
        room: user.room,
        users: getRoomUsers(user.room)
      });
    }
  });
});

}
catch(e){
	// res.send('error')
  socket.emit('redirect', '/logout');
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const PORT = process.env.PORT || 3000;

rooms=["GC","OAT","Cauvery","Usha","Himalaya","Sangam","SAC","WatsaStadium","ShoppingCentre"]
app.get('/roomdetails/:room',isLoggedIn, (req,res)=>{
	const room = req.params.room;
	if(!rooms.includes(room)) return res.send("Here's a message from Big Smoke: 'You picked the wrong room fool' ")

  res.render('chat', {username: req.user._json.name, room: room })
})

// app.get('/test', (req,res)=>{
//   res.render('test',{username: 'John', room: 'GC'})
// })

server.listen(PORT, () => console.log(`Server running on port ${PORT}`));