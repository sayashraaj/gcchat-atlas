module.exports={
	clientID: "697810081501-r07964k1tm5iqqde6pfm992o5e70tsh6.apps.googleusercontent.com",
	clientSecret: "yQdxffDfh4K1qxhruLScccup"
};