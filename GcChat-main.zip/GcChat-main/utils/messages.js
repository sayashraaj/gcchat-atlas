function calcTime(city, offset) {
    d = new Date();
    utc = d.getTime() + (d.getTimezoneOffset() * 60000);
    nd = new Date(utc + (3600000*offset));
    return nd.toLocaleString();
}


function formatMessage(username, text) {
	// var indiaTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
	// var result = indiaTime.match(/\d\d:\d\d/);
  return {
    username,
    text,
    // time: result[0]
    time: calcTime('Bombay', '+5.5')
  };
}

module.exports = formatMessage;
